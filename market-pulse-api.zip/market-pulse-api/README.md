# Market Pulse API

Real-time crypto market data, order-flow alerting, and a rate-limited REST API — built to run on Replit with zero paid API keys required to get started.

A background worker polls live ticker data (Binance by default, CoinGecko as a swappable fallback), evaluates it against configurable alert rules, and pushes notifications to Discord and/or Telegram the moment something interesting happens — a price spike, a sharp drop, a volume surge, or a custom threshold cross. All the same data is exposed through a clean, rate-limited REST API so you can build a dashboard, bot, or trading tool on top of it.

## Why this exists

Most "crypto alert bot" tutorials are a single 200-line script that polls an API and prints to console. This project is structured like something you'd actually ship: typed data models, a provider abstraction so the data source is swappable, a decoupled alert engine, a pluggable notifier, and a rate-limited API — all in small, single-responsibility modules.

## Features

- **Live market polling** — async background worker tracks any list of symbols on a configurable interval
- **Swappable data providers** — Binance (no API key) or CoinGecko out of the box; add a new source by implementing one interface
- **Smart alerting** — built-in heuristics (% price change, cooldown-protected) plus user-defined rules (`threshold_cross`, `volume_spike`, etc.) added at runtime via the API
- **Multi-channel notifications** — Discord webhook and/or Telegram bot; falls back to console logging if neither is configured
- **Rate-limited REST API** — FastAPI + `slowapi`, per-route limits, auto-generated docs at `/docs`
- **Alert history** — every fired alert is retained in memory and queryable via `/alerts/history`

## Architecture

```
app/
├── main.py                # composition root — wires everything, no logic
├── config.py               # all env-driven settings, one source of truth
├── core/
│   ├── logging_config.py   # shared logging setup
│   └── rate_limiter.py     # slowapi limiter instance
├── models/
│   └── schemas.py          # Pydantic models shared by every layer
├── providers/               # data sources — one interface, swappable backends
│   ├── base.py              #   MarketDataProvider ABC
│   ├── binance_provider.py
│   └── coingecko_provider.py
├── services/
│   ├── market_service.py   # provider orchestration + store writes
│   ├── alert_engine.py     # rule evaluation + cooldown logic
│   └── notifier.py         # Discord / Telegram delivery
├── workers/
│   └── monitor.py          # the poll → evaluate → notify loop
├── store/
│   └── memory_store.py     # in-memory store shared by API + worker
└── api/
    ├── routes_health.py
    ├── routes_prices.py
    └── routes_alerts.py
```

**Data flow:** `monitor.py` polls `market_service` on an interval → fresh ticks are written to `memory_store` → each tick is run through `alert_engine` → any fired `AlertEvent` goes to `notifier` (Discord/Telegram) and is stored in alert history. The API layer reads from the same store, so `/prices` always reflects what the monitor just saw.

## Getting started (Replit)

1. **Import this repo** into a new Replit (Import from GitHub).
2. Replit auto-detects `requirements.txt` and installs dependencies on first run.
3. Copy `.env.example` → `.env` and fill in what you need (see below). Everything works with zero keys — alerts just log to console instead of Discord/Telegram until you add webhook credentials.
4. Hit **Run**. The API comes up at your Repl's URL, background monitoring starts automatically.
5. Open `/docs` for interactive Swagger UI.

### Running locally instead

```bash
git clone <your-repo-url>
cd market-pulse-api
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

## Configuration

All settings are environment variables (see `.env.example`):

| Variable | Default | Description |
|---|---|---|
| `TRACKED_SYMBOLS` | `BTCUSDT,ETHUSDT,SOLUSDT` | Comma-separated symbols to monitor |
| `MARKET_PROVIDER` | `binance` | `binance` or `coingecko` |
| `POLL_INTERVAL_SECONDS` | `15` | How often the monitor refreshes data |
| `PRICE_CHANGE_THRESHOLD_PCT` | `2.0` | 24h % move that triggers a built-in alert |
| `ALERT_COOLDOWN_SECONDS` | `300` | Minimum time between repeat alerts for the same symbol/type |
| `RATE_LIMIT` | `60/minute` | Default API rate limit per client IP |
| `DISCORD_WEBHOOK_URL` | — | Optional. Enables Discord alerts |
| `TELEGRAM_BOT_TOKEN` / `TELEGRAM_CHAT_ID` | — | Optional. Enables Telegram alerts |

## API Reference

Base path: `/api/v1`

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/health` | Liveness check |
| `GET` | `/prices` | Latest tick for every tracked symbol |
| `GET` | `/prices/{symbol}` | Latest tick for one symbol, e.g. `/prices/BTCUSDT` |
| `GET` | `/alerts/rules` | List all custom alert rules |
| `POST` | `/alerts/rules` | Create a custom alert rule |
| `DELETE` | `/alerts/rules/{rule_id}` | Remove an alert rule |
| `GET` | `/alerts/history?limit=50` | Recently fired alerts |

**Example — create a custom rule:**

```bash
curl -X POST https://your-repl-url/api/v1/alerts/rules \
  -H "Content-Type: application/json" \
  -d '{"symbol": "BTCUSDT", "alert_type": "threshold_cross", "threshold": 70000}'
```

Alert types: `price_spike`, `price_drop`, `volume_spike`, `threshold_cross`.

## Extending it

- **Add a new data source** (e.g. a stock ticker API): implement `MarketDataProvider` in `app/providers/`, then point `MARKET_PROVIDER` at it in `market_service.build_provider()`.
- **Add a new notification channel**: add a private `_send_x` method to `Notifier` in `app/services/notifier.py` and call it from `dispatch()`.
- **Persist state instead of in-memory**: swap `MemoryStore` for a Redis/Postgres-backed implementation — it's the only place that needs to change.

## Roadmap

- [ ] WebSocket endpoint for live tick streaming to a frontend dashboard
- [ ] Moving-average crossover alert type
- [ ] Swap in-memory store for Redis for multi-instance deployments
- [ ] Stock ticker provider (Finnhub/Alpha Vantage)

## Tech stack

Python · FastAPI · slowapi (rate limiting) · httpx (async HTTP) · Pydantic · Uvicorn

## License

MIT
