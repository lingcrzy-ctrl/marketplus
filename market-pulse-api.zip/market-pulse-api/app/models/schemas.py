"""
Pydantic models used across providers, services, and API routes.

Keeping these in one module means a provider and an API route are always
talking about the same shape of data — no drift between layers.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class Tick(BaseModel):
    """A single price observation for a symbol at a point in time."""

    symbol: str
    price: float
    volume_24h: float = 0.0
    percent_change_24h: float = 0.0
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class AlertType(str, Enum):
    PRICE_SPIKE = "price_spike"
    PRICE_DROP = "price_drop"
    VOLUME_SPIKE = "volume_spike"
    THRESHOLD_CROSS = "threshold_cross"


class AlertRule(BaseModel):
    """A user-defined condition that should trigger a notification."""

    id: Optional[str] = None
    symbol: str
    alert_type: AlertType
    threshold: float
    enabled: bool = True


class AlertEvent(BaseModel):
    """A rule that has actually fired, ready to be delivered/logged."""

    rule_id: Optional[str]
    symbol: str
    alert_type: AlertType
    message: str
    tick: Tick
    triggered_at: datetime = Field(default_factory=datetime.utcnow)
