"""
Simple in-memory store.

This is intentionally minimal — a dict behind a small typed interface —
so the API and background worker share one source of truth without
either of them knowing it's "just a dict". Swapping this for Redis or
Postgres later only means rewriting this one file.
"""

from __future__ import annotations

import itertools
from collections import deque
from typing import Dict, List, Optional

from app.models.schemas import AlertEvent, AlertRule, Tick


class MemoryStore:
    def __init__(self, max_alert_history: int = 200) -> None:
        self._latest_ticks: Dict[str, Tick] = {}
        self._rules: Dict[str, AlertRule] = {}
        self._alert_history: deque[AlertEvent] = deque(maxlen=max_alert_history)
        self._id_counter = itertools.count(1)

    # --- Ticks ---
    def upsert_tick(self, tick: Tick) -> None:
        self._latest_ticks[tick.symbol] = tick

    def get_tick(self, symbol: str) -> Optional[Tick]:
        return self._latest_ticks.get(symbol)

    def all_ticks(self) -> List[Tick]:
        return list(self._latest_ticks.values())

    # --- Alert rules ---
    def add_rule(self, rule: AlertRule) -> AlertRule:
        rule.id = str(next(self._id_counter))
        self._rules[rule.id] = rule
        return rule

    def remove_rule(self, rule_id: str) -> bool:
        return self._rules.pop(rule_id, None) is not None

    def all_rules(self) -> List[AlertRule]:
        return list(self._rules.values())

    def rules_for_symbol(self, symbol: str) -> List[AlertRule]:
        return [r for r in self._rules.values() if r.symbol == symbol and r.enabled]

    # --- Alert history ---
    def record_alert(self, event: AlertEvent) -> None:
        self._alert_history.appendleft(event)

    def recent_alerts(self, limit: int = 50) -> List[AlertEvent]:
        return list(itertools.islice(self._alert_history, limit))


# Single shared instance for the life of the process.
store = MemoryStore()
