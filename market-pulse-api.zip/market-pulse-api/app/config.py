"""
Centralized configuration.

Everything the app needs to know about its environment lives here so no
other module has to touch `os.environ` directly. Values are loaded once
at import time and validated with sane defaults for local/Replit use.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import List

from dotenv import load_dotenv

load_dotenv()


def _split_csv(value: str) -> List[str]:
    return [item.strip().upper() for item in value.split(",") if item.strip()]


@dataclass(frozen=True)
class Settings:
    # --- API ---
    app_name: str = "Market Pulse API"
    api_prefix: str = "/api/v1"
    rate_limit: str = os.getenv("RATE_LIMIT", "60/minute")

    # --- Market data ---
    tracked_symbols: List[str] = field(
        default_factory=lambda: _split_csv(os.getenv("TRACKED_SYMBOLS", "BTCUSDT,ETHUSDT,SOLUSDT"))
    )
    poll_interval_seconds: int = int(os.getenv("POLL_INTERVAL_SECONDS", "15"))
    provider: str = os.getenv("MARKET_PROVIDER", "binance")  # binance | coingecko

    # --- Alerting ---
    price_change_threshold_pct: float = float(os.getenv("PRICE_CHANGE_THRESHOLD_PCT", "2.0"))
    volume_spike_multiplier: float = float(os.getenv("VOLUME_SPIKE_MULTIPLIER", "3.0"))
    alert_cooldown_seconds: int = int(os.getenv("ALERT_COOLDOWN_SECONDS", "300"))

    # --- Notifications ---
    discord_webhook_url: str = os.getenv("DISCORD_WEBHOOK_URL", "")
    telegram_bot_token: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    telegram_chat_id: str = os.getenv("TELEGRAM_CHAT_ID", "")

    # --- Misc ---
    log_level: str = os.getenv("LOG_LEVEL", "INFO")


settings = Settings()
