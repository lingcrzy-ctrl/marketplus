"""Market Pulse API — real-time market data, alerting, and order-flow signals."""

__version__ = "0.1.0"
