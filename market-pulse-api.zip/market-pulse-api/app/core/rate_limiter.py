"""
Rate limiting, isolated in its own module so `main.py` stays a thin
composition root instead of a dumping ground for middleware config.
"""

from slowapi import Limiter
from slowapi.util import get_remote_address

from app.config import settings

limiter = Limiter(key_func=get_remote_address, default_limits=[settings.rate_limit])
