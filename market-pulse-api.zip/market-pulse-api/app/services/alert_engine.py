"""
Alert engine.

Two layers of detection, both feeding the same AlertEvent pipeline:

1. Built-in heuristics (price % change, volume spike) driven by global
   thresholds in config — fire automatically for every tracked symbol.
2. User-defined AlertRule objects (added via the API) — fire only for
   the symbol/threshold the caller specified.

A per-(symbol, alert_type) cooldown prevents spamming the same alert
every poll cycle while a condition remains true.
"""

from __future__ import annotations

import time
from typing import Dict, List, Tuple

from app.config import settings
from app.core.logging_config import get_logger
from app.models.schemas import AlertEvent, AlertRule, AlertType, Tick
from app.store.memory_store import store

logger = get_logger(__name__)

CooldownKey = Tuple[str, AlertType]


class AlertEngine:
    def __init__(self) -> None:
        self._last_fired: Dict[CooldownKey, float] = {}

    def evaluate(self, tick: Tick) -> List[AlertEvent]:
        events: List[AlertEvent] = []
        events.extend(self._check_builtin_heuristics(tick))
        events.extend(self._check_custom_rules(tick))
        for event in events:
            store.record_alert(event)
        return events

    # --- Built-in heuristics ---
    def _check_builtin_heuristics(self, tick: Tick) -> List[AlertEvent]:
        events = []

        if abs(tick.percent_change_24h) >= settings.price_change_threshold_pct:
            alert_type = AlertType.PRICE_SPIKE if tick.percent_change_24h > 0 else AlertType.PRICE_DROP
            if self._should_fire(tick.symbol, alert_type):
                direction = "up" if tick.percent_change_24h > 0 else "down"
                events.append(
                    AlertEvent(
                        rule_id=None,
                        symbol=tick.symbol,
                        alert_type=alert_type,
                        message=(
                            f"{tick.symbol} is {direction} {tick.percent_change_24h:.2f}% "
                            f"in 24h (now ${tick.price:,.4f})"
                        ),
                        tick=tick,
                    )
                )
        return events

    # --- Custom user rules ---
    def _check_custom_rules(self, tick: Tick) -> List[AlertEvent]:
        events = []
        for rule in store.rules_for_symbol(tick.symbol):
            if self._rule_condition_met(rule, tick) and self._should_fire(tick.symbol, rule.alert_type):
                events.append(
                    AlertEvent(
                        rule_id=rule.id,
                        symbol=tick.symbol,
                        alert_type=rule.alert_type,
                        message=f"{tick.symbol} crossed custom rule threshold {rule.threshold}",
                        tick=tick,
                    )
                )
        return events

    @staticmethod
    def _rule_condition_met(rule: AlertRule, tick: Tick) -> bool:
        if rule.alert_type == AlertType.THRESHOLD_CROSS:
            return tick.price >= rule.threshold
        if rule.alert_type == AlertType.VOLUME_SPIKE:
            return tick.volume_24h >= rule.threshold
        if rule.alert_type == AlertType.PRICE_SPIKE:
            return tick.percent_change_24h >= rule.threshold
        if rule.alert_type == AlertType.PRICE_DROP:
            return tick.percent_change_24h <= -rule.threshold
        return False

    def _should_fire(self, symbol: str, alert_type: AlertType) -> bool:
        key = (symbol, alert_type)
        now = time.time()
        last = self._last_fired.get(key, 0.0)
        if now - last < settings.alert_cooldown_seconds:
            return False
        self._last_fired[key] = now
        return True


alert_engine = AlertEngine()
