"""
Notifier.

Delivers AlertEvents to whichever channels are configured. Each channel
is a small private method behind one public `dispatch` call, so adding
a new channel (Slack, email, SMS...) never touches the alert engine.
"""

from __future__ import annotations

import httpx

from app.config import settings
from app.core.logging_config import get_logger
from app.models.schemas import AlertEvent

logger = get_logger(__name__)


class Notifier:
    def __init__(self) -> None:
        self._client = httpx.AsyncClient(timeout=10.0)

    async def dispatch(self, event: AlertEvent) -> None:
        if settings.discord_webhook_url:
            await self._send_discord(event)
        if settings.telegram_bot_token and settings.telegram_chat_id:
            await self._send_telegram(event)
        if not settings.discord_webhook_url and not settings.telegram_bot_token:
            logger.info("[alert] %s", event.message)

    async def _send_discord(self, event: AlertEvent) -> None:
        payload = {"content": f"🚨 **{event.alert_type.value.upper()}** — {event.message}"}
        try:
            response = await self._client.post(settings.discord_webhook_url, json=payload)
            response.raise_for_status()
        except httpx.HTTPError as exc:
            logger.warning("Discord delivery failed: %s", exc)

    async def _send_telegram(self, event: AlertEvent) -> None:
        url = f"https://api.telegram.org/bot{settings.telegram_bot_token}/sendMessage"
        payload = {
            "chat_id": settings.telegram_chat_id,
            "text": f"🚨 {event.alert_type.value.upper()} — {event.message}",
        }
        try:
            response = await self._client.post(url, json=payload)
            response.raise_for_status()
        except httpx.HTTPError as exc:
            logger.warning("Telegram delivery failed: %s", exc)

    async def aclose(self) -> None:
        await self._client.aclose()


notifier = Notifier()
