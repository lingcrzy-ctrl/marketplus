"""
Market data service.

Thin orchestration layer between the provider (raw data source) and the
rest of the app: picks the right provider from config, fetches ticks,
and writes them into the store. API routes and the background worker
both go through this instead of touching providers directly.
"""

from __future__ import annotations

from typing import List

from app.config import settings
from app.core.logging_config import get_logger
from app.models.schemas import Tick
from app.providers.base import MarketDataProvider
from app.providers.binance_provider import BinanceProvider
from app.providers.coingecko_provider import CoinGeckoProvider
from app.store.memory_store import store

logger = get_logger(__name__)


def build_provider() -> MarketDataProvider:
    """Factory that reads config once and returns the configured provider."""
    if settings.provider == "coingecko":
        return CoinGeckoProvider()
    return BinanceProvider()


class MarketService:
    def __init__(self, provider: MarketDataProvider | None = None) -> None:
        self.provider = provider or build_provider()

    async def refresh(self, symbols: List[str]) -> List[Tick]:
        """Fetch fresh ticks for the given symbols and persist them."""
        ticks = await self.provider.fetch_ticks(symbols)
        for tick in ticks:
            store.upsert_tick(tick)
        logger.debug("Refreshed %d symbols", len(ticks))
        return ticks

    @staticmethod
    def get_latest(symbol: str) -> Tick | None:
        return store.get_tick(symbol.upper())

    @staticmethod
    def get_all_latest() -> List[Tick]:
        return store.all_ticks()
