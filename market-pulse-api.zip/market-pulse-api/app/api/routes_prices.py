from fastapi import APIRouter, HTTPException, Request

from app.core.rate_limiter import limiter
from app.models.schemas import Tick
from app.services.market_service import MarketService

router = APIRouter(prefix="/prices", tags=["prices"])
market_service = MarketService()


@router.get("", response_model=list[Tick])
@limiter.limit("60/minute")
async def list_prices(request: Request) -> list[Tick]:
    """Latest cached tick for every tracked symbol."""
    return market_service.get_all_latest()


@router.get("/{symbol}", response_model=Tick)
@limiter.limit("60/minute")
async def get_price(request: Request, symbol: str) -> Tick:
    """Latest cached tick for a single symbol, e.g. /prices/BTCUSDT."""
    tick = market_service.get_latest(symbol)
    if tick is None:
        raise HTTPException(status_code=404, detail=f"No data yet for '{symbol}'")
    return tick
