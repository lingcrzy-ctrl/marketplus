from fastapi import APIRouter, HTTPException, Request

from app.core.rate_limiter import limiter
from app.models.schemas import AlertEvent, AlertRule
from app.store.memory_store import store

router = APIRouter(prefix="/alerts", tags=["alerts"])


@router.get("/rules", response_model=list[AlertRule])
@limiter.limit("60/minute")
async def list_rules(request: Request) -> list[AlertRule]:
    return store.all_rules()


@router.post("/rules", response_model=AlertRule, status_code=201)
@limiter.limit("20/minute")
async def create_rule(request: Request, rule: AlertRule) -> AlertRule:
    """
    Add a custom alert rule.

    Example body:
    {"symbol": "BTCUSDT", "alert_type": "threshold_cross", "threshold": 70000}
    """
    return store.add_rule(rule)


@router.delete("/rules/{rule_id}", status_code=204)
@limiter.limit("20/minute")
async def delete_rule(request: Request, rule_id: str) -> None:
    if not store.remove_rule(rule_id):
        raise HTTPException(status_code=404, detail=f"Rule '{rule_id}' not found")


@router.get("/history", response_model=list[AlertEvent])
@limiter.limit("60/minute")
async def alert_history(request: Request, limit: int = 50) -> list[AlertEvent]:
    return store.recent_alerts(limit)
