"""
Binance public REST API provider.

Uses the unauthenticated /ticker/24hr endpoint, so no API key is needed
to get started. Good default for crypto tickers on a free Replit deploy.
"""

from __future__ import annotations

import httpx

from app.core.logging_config import get_logger
from app.models.schemas import Tick
from app.providers.base import MarketDataProvider

logger = get_logger(__name__)

BASE_URL = "https://api.binance.com/api/v3/ticker/24hr"


class BinanceProvider(MarketDataProvider):
    def __init__(self, timeout: float = 10.0) -> None:
        self._client = httpx.AsyncClient(timeout=timeout)

    async def fetch_tick(self, symbol: str) -> Tick:
        response = await self._client.get(BASE_URL, params={"symbol": symbol})
        response.raise_for_status()
        data = response.json()
        return self._to_tick(data)

    async def fetch_ticks(self, symbols: list[str]) -> list[Tick]:
        # Binance supports a bulk call with a JSON array of symbols.
        symbols_param = str(symbols).replace("'", '"')
        response = await self._client.get(BASE_URL, params={"symbols": symbols_param})
        response.raise_for_status()
        return [self._to_tick(item) for item in response.json()]

    @staticmethod
    def _to_tick(data: dict) -> Tick:
        return Tick(
            symbol=data["symbol"],
            price=float(data["lastPrice"]),
            volume_24h=float(data["volume"]),
            percent_change_24h=float(data["priceChangePercent"]),
        )

    async def aclose(self) -> None:
        await self._client.aclose()
