"""
Provider interface.

Every data source (Binance, CoinGecko, a future stock API, etc.) implements
this contract. The rest of the app never imports a concrete provider
directly — it depends on this abstraction, so swapping or adding a source
never touches the service or API layer.
"""

from abc import ABC, abstractmethod
from typing import List

from app.models.schemas import Tick


class MarketDataProvider(ABC):
    @abstractmethod
    async def fetch_tick(self, symbol: str) -> Tick:
        """Fetch the latest tick for a single symbol."""

    async def fetch_ticks(self, symbols: List[str]) -> List[Tick]:
        """Fetch ticks for multiple symbols. Providers may override this
        with a bulk endpoint; the default just fans out one-by-one."""
        return [await self.fetch_tick(symbol) for symbol in symbols]
