"""
CoinGecko provider — fallback source, handy in regions where Binance's
API is geo-blocked. Symbols are CoinGecko coin ids (e.g. "bitcoin"),
not exchange pairs, so this is intentionally kept separate from the
Binance symbol format rather than forcing a shared translation layer.
"""

from __future__ import annotations

import httpx

from app.models.schemas import Tick
from app.providers.base import MarketDataProvider

BASE_URL = "https://api.coingecko.com/api/v3/simple/price"


class CoinGeckoProvider(MarketDataProvider):
    def __init__(self, timeout: float = 10.0) -> None:
        self._client = httpx.AsyncClient(timeout=timeout)

    async def fetch_tick(self, symbol: str) -> Tick:
        params = {
            "ids": symbol,
            "vs_currencies": "usd",
            "include_24hr_vol": "true",
            "include_24hr_change": "true",
        }
        response = await self._client.get(BASE_URL, params=params)
        response.raise_for_status()
        payload = response.json().get(symbol, {})
        return Tick(
            symbol=symbol,
            price=float(payload.get("usd", 0.0)),
            volume_24h=float(payload.get("usd_24h_vol", 0.0)),
            percent_change_24h=float(payload.get("usd_24h_change", 0.0)),
        )

    async def aclose(self) -> None:
        await self._client.aclose()
