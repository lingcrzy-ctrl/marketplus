"""
Background monitor loop.

Runs as an asyncio task alongside the FastAPI app (started in the
lifespan handler in main.py). Polls tracked symbols on an interval,
feeds fresh ticks through the alert engine, and dispatches any events
that fire. This is the "order-flow automation" heartbeat of the app.
"""

from __future__ import annotations

import asyncio

from app.config import settings
from app.core.logging_config import get_logger
from app.services.alert_engine import alert_engine
from app.services.market_service import MarketService
from app.services.notifier import notifier

logger = get_logger(__name__)


class MarketMonitor:
    def __init__(self, market_service: MarketService | None = None) -> None:
        self.market_service = market_service or MarketService()
        self._running = False

    async def run_forever(self) -> None:
        self._running = True
        logger.info(
            "Monitor started — tracking %s every %ss",
            settings.tracked_symbols,
            settings.poll_interval_seconds,
        )
        while self._running:
            try:
                await self._poll_once()
            except Exception:  # noqa: BLE001 — keep the loop alive on any single failure
                logger.exception("Poll cycle failed, retrying next interval")
            await asyncio.sleep(settings.poll_interval_seconds)

    async def _poll_once(self) -> None:
        ticks = await self.market_service.refresh(settings.tracked_symbols)
        for tick in ticks:
            events = alert_engine.evaluate(tick)
            for event in events:
                logger.info("ALERT: %s", event.message)
                await notifier.dispatch(event)

    def stop(self) -> None:
        self._running = False


monitor = MarketMonitor()
