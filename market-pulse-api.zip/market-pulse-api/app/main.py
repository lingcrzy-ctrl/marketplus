"""
Application entrypoint.

This file is deliberately thin: it wires config, middleware, routers,
and the background monitor together, and does nothing else. Business
logic lives in services/, workers/, and providers/.
"""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager

from fastapi import FastAPI
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware

from app.api import routes_alerts, routes_health, routes_prices
from app.config import settings
from app.core.logging_config import configure_logging, get_logger
from app.core.rate_limiter import limiter
from app.workers.monitor import monitor

configure_logging()
logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    task = asyncio.create_task(monitor.run_forever())
    logger.info("%s starting up", settings.app_name)
    yield
    monitor.stop()
    task.cancel()
    logger.info("%s shutting down", settings.app_name)


app = FastAPI(title=settings.app_name, lifespan=lifespan)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.add_middleware(SlowAPIMiddleware)

app.include_router(routes_health.router, prefix=settings.api_prefix)
app.include_router(routes_prices.router, prefix=settings.api_prefix)
app.include_router(routes_alerts.router, prefix=settings.api_prefix)


@app.get("/")
async def root() -> dict:
    return {
        "name": settings.app_name,
        "docs": "/docs",
        "tracked_symbols": settings.tracked_symbols,
    }
